from zabbix_pyapi import Zabbix_PyAPI
